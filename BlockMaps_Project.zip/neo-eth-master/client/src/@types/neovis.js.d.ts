declare module "neovis.js" {
  var x: any;
  export = x;
}
